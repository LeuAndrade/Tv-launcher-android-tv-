# TV Launcher (estilo Google TV)

## Como gerar o APK
1. Instale o Android Studio (Koala ou mais novo) e abra esta pasta.
2. Crie chaves gratuitas:
   - TMDB: https://www.themoviedb.org/settings/api  (API Key v3)
   - OMDb: https://www.omdbapi.com/apikey.aspx
3. No arquivo `local.properties` (criado pelo Android Studio) adicione:
   ```
   TMDB_KEY=sua_chave_tmdb
   OMDB_KEY=sua_chave_omdb
   ```
4. Aguarde o Gradle sincronizar e use **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
   O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.
5. Instale na TV: `adb connect IP_DA_TV` e `adb install app-debug.apk`.

## Funcionalidades
- Destaque rotativo na tela inicial
- Carrosséis: Continuar assistindo, Minha lista, Recomendados, Em alta, Em cartaz, Filmes/Séries populares, Mais bem avaliados
- Detalhes: sinopse, elenco, gêneros, duração, notas IMDb / Rotten Tomatoes / Metacritic / TMDB
- Onde assistir no Brasil (streaming, aluguel, compra) e abertura do app do provedor
- Trailer (YouTube), títulos semelhantes
- Marcar como assistido, Minha lista, Continuar assistindo com barra de progresso
- Busca por texto e por voz
- Aba Apps com todos os apps instalados
- Funciona com controle remoto (D-pad)
