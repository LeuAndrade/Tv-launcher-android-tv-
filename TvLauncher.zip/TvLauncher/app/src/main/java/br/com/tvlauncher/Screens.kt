package br.com.tvlauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ═════════════════════════════ INÍCIO ═════════════════════════════
@Composable
fun HomeScreen(onOpen: (Poster) -> Unit) {
    val mine by LauncherApp.db.dao().all().collectAsState(emptyList())
    val shelves by produceState<List<Shelf>?>(null) { value = Repo.homeShelves() }
    val seed = mine.firstOrNull { it.watched || it.inList }
    val recs by produceState(emptyList<MediaItem>(), seed?.uid) { value = Repo.recommendations(seed) }

    LazyColumn(contentPadding = PaddingValues(bottom = 48.dp)) {
        val s = shelves
        when {
            s == null -> item { T("Carregando…", 18, modifier = Modifier.padding(48.dp)) }
            s.all { it.items.isEmpty() } -> item {
                T(
                    "Não foi possível carregar o catálogo. Verifique a internet e as chaves TMDB_KEY e OMDB_KEY no local.properties.",
                    16, modifier = Modifier.padding(48.dp)
                )
            }
            else -> {
                val featured = s.first().items.filter { it.backdropPath != null }.take(6)
                if (featured.isNotEmpty()) item { Hero(featured, onOpen) }
                item { PosterRow("Continuar assistindo", mine.filter { it.watching }.map { it.toPoster() }, onOpen) }
                item { PosterRow("Minha lista", mine.filter { it.inList && !it.watched }.map { it.toPoster() }, onOpen) }
                item {
                    PosterRow(
                        if (seed != null) "Recomendados para você" else "Descubra",
                        recs.map { it.toPoster() }, onOpen
                    )
                }
                s.forEach { shelf -> item { PosterRow(shelf.title, shelf.items.map { it.toPoster() }, onOpen) } }
            }
        }
    }
}

@Composable
fun Hero(items: List<MediaItem>, onOpen: (Poster) -> Unit) {
    var idx by remember { mutableStateOf(0) }
    LaunchedEffect(items) { while (true) { delay(8000); idx = (idx + 1) % items.size } }
    val m = items[idx.coerceIn(items.indices)]
    Box(Modifier.fillMaxWidth().height(280.dp)) {
        AsyncImage(img(m.backdropPath, "w1280"), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Bg, Color(0x990E0F13), Color.Transparent))))
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Bg))))
        Column(
            Modifier.align(Alignment.CenterStart).padding(start = 48.dp).width(420.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            T("EM DESTAQUE", 12, true, color = Accent)
            T(m.label, 28, true, maxLines = 2)
            T("★ %.1f  ·  %s  ·  %s".format(m.voteAverage ?: 0.0, m.year, if (m.mediaType == "tv") "Série" else "Filme"), 13)
            T(m.overview.orEmpty(), 13, maxLines = 3)
            Btn("Ver detalhes") { onOpen(m.toPoster()) }
        }
    }
}

// ═════════════════════════════ DETALHES ═════════════════════════════
@Composable
fun DetailScreen(type: String, id: Int, onOpen: (Poster) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dao = LauncherApp.db.dao()
    val uid = "$type:$id"

    val state by produceState<Result<Detail>?>(null, uid) { value = runCatching { Net.tmdb.detail(type, id) } }
    val d = state?.getOrNull()
    val omdb by produceState<Omdb?>(null, d?.imdb) { value = d?.imdb?.let { Repo.ratings(it) } }
    val user by dao.one(uid).collectAsState(null)
    val similar by produceState(emptyList<MediaItem>(), uid) { value = Repo.similar(type, id) }

    if (state == null) { Box(Modifier.fillMaxSize(), Alignment.Center) { T("Carregando…", 18) }; return }
    if (d == null) { Box(Modifier.fillMaxSize(), Alignment.Center) { T("Não foi possível carregar este título.", 18) }; return }

    val u = user
    fun edit(f: (UserTitle) -> UserTitle) {
        scope.launch {
            val base = u ?: UserTitle(uid, id, type, d.label, d.posterPath, d.backdropPath)
            dao.upsert(f(base).copy(updatedAt = System.currentTimeMillis()))
        }
    }
    fun bump(delta: Int) = edit {
        val p = (it.progress + delta).coerceIn(0, 100)
        if (p >= 100) it.copy(watching = false, watched = true, progress = 0)
        else it.copy(progress = p, watching = true, watched = false)
    }

    val region = d.providers?.results?.get("BR")
    val groups = listOf("Streaming" to region?.flatrate, "Alugar" to region?.rent, "Comprar" to region?.buy)
        .filter { !it.second.isNullOrEmpty() }

    Box(Modifier.fillMaxSize()) {
        AsyncImage(img(d.backdropPath, "w1280"), null, Modifier.fillMaxSize().alpha(0.22f), contentScale = ContentScale.Crop)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 48.dp, vertical = 16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                AsyncImage(
                    img(d.posterPath, "w500"), d.label,
                    Modifier.width(190.dp).height(285.dp).clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop
                )
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    T(d.label, 28, true)
                    val meta = listOf(
                        d.year,
                        d.genres.orEmpty().mapNotNull { it.name }.take(3).joinToString(", "),
                        d.runtime?.takeIf { it > 0 }?.let { "${it / 60}h ${it % 60}min" } ?: ""
                    ).filter { it.isNotBlank() }.joinToString("  ·  ")
                    T(meta, 13)

                    // Notas: IMDb, Rotten Tomatoes, Metacritic (OMDb) + TMDB
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        omdb?.ratings.orEmpty().forEach { r ->
                            val name = when (r.source) {
                                "Internet Movie Database" -> "IMDb"
                                "Rotten Tomatoes" -> "🍅 Rotten Tomatoes"
                                else -> r.source ?: ""
                            }
                            Chip("$name ${r.value}")
                        }
                        d.voteAverage?.takeIf { it > 0 }?.let { Chip("TMDB %.1f".format(it)) }
                    }
                    if (!d.tagline.isNullOrBlank()) T("“${d.tagline}”", 13)
                    T(d.overview.orEmpty().ifBlank { "Sem sinopse em português." }, 13, maxLines = 6)
                    val cast = d.credits?.cast.orEmpty().mapNotNull { it.name }.take(8).joinToString(", ")
                    if (cast.isNotBlank()) T("Elenco: $cast", 12)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Btn(if (u?.inList == true) "✓ Na minha lista" else "+ Minha lista") {
                            edit { it.copy(inList = !it.inList) }
                        }
                        Btn(if (u?.watched == true) "✓ Já assisti" else "Marcar como assistido") {
                            edit { it.copy(watched = !it.watched, watching = false, progress = 0) }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Btn(if (u?.watching == true) "▶ Em andamento ✓" else "▶ Continuar assistindo") {
                            edit { it.copy(watching = !it.watching, watched = false) }
                        }
                        d.trailerKey?.let { key -> Btn("Trailer") { openTrailer(ctx, key) } }
                    }
                    if (u?.watching == true) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            T("Progresso: ${u.progress}%", 13, true)
                            Btn("−10%") { bump(-10) }
                            Btn("+10%") { bump(10) }
                        }
                    }
                }
            }

            // Onde assistir
            T("Onde assistir (Brasil)", 18, true, Modifier.padding(top = 24.dp, bottom = 8.dp))
            if (groups.isEmpty()) {
                T("Nenhuma disponibilidade encontrada para o Brasil.", 13)
            } else {
                groups.forEach { (label, list) ->
                    T(label, 13, true, Modifier.padding(vertical = 6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(list.orEmpty()) { p ->
                            Focusable({
                                val opened = launchProvider(ctx, p.name.orEmpty(), region?.link)
                                if (opened) edit { it.copy(watching = true, watched = false) }
                                else Toast.makeText(ctx, "Não foi possível abrir ${p.name}", Toast.LENGTH_SHORT).show()
                            }) {
                                Row(
                                    Modifier.background(Color(0x33FFFFFF)).padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    AsyncImage(
                                        img(p.logo, "w92"), null,
                                        Modifier.size(32.dp).clip(RoundedCornerShape(6.dp))
                                    )
                                    T(p.name.orEmpty(), 13, true)
                                }
                            }
                        }
                    }
                }
                T("Dados de disponibilidade: JustWatch (via TMDB)", 10, modifier = Modifier.padding(top = 8.dp).alpha(0.6f))
            }

            Spacer(Modifier.height(8.dp))
            Column(Modifier.padding(horizontal = 0.dp).offset(x = (-48).dp).width(960.dp)) {
                PosterRow("Títulos semelhantes", similar.map { it.toPoster() }, onOpen)
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

private val PROVIDER_PACKAGES = mapOf(
    "netflix" to listOf("com.netflix.ninja", "com.netflix.mediaclient"),
    "prime video" to listOf("com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient"),
    "disney" to listOf("com.disney.disneyplus"),
    "max" to listOf("com.wbd.stream", "com.hbo.hbonow"),
    "globoplay" to listOf("com.globo.globotv"),
    "apple tv" to listOf("com.apple.atve.androidtv.appletv"),
    "paramount" to listOf("com.cbs.ott", "com.cbs.app"),
    "youtube" to listOf("com.google.android.youtube.tv", "com.google.android.youtube"),
    "google play" to listOf("com.google.android.videos")
)

/** Abre o app do provedor se estiver instalado; senão abre a página do JustWatch/TMDB. */
fun launchProvider(ctx: Context, name: String, link: String?): Boolean {
    val pm = ctx.packageManager
    val n = name.lowercase()
    val intent = PROVIDER_PACKAGES.entries.firstOrNull { n.contains(it.key) }?.value
        ?.firstNotNullOfOrNull { pm.getLeanbackLaunchIntentForPackage(it) ?: pm.getLaunchIntentForPackage(it) }
        ?: link?.let { Intent(Intent.ACTION_VIEW, Uri.parse(it)) }
        ?: return false
    return runCatching { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
}

fun openTrailer(ctx: Context, key: String) {
    val app = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:$key")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    val web = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$key")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (runCatching { ctx.startActivity(app) }.isFailure && runCatching { ctx.startActivity(web) }.isFailure)
        Toast.makeText(ctx, "Nenhum app para abrir o trailer", Toast.LENGTH_SHORT).show()
}

// ═════════════════════════════ BUSCA ═════════════════════════════
@Composable
fun SearchScreen(onOpen: (Poster) -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MediaItem>>(emptyList()) }

    LaunchedEffect(query) {
        if (query.trim().length < 2) { results = emptyList(); return@LaunchedEffect }
        delay(400)
        results = Repo.search(query.trim())
    }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { query = it }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                    .background(Color(0x33FFFFFF)).padding(14.dp),
                decorationBox = { inner ->
                    if (query.isEmpty()) T("Buscar filmes e séries…", 18, modifier = Modifier.alpha(0.5f))
                    inner()
                }
            )
            Btn("🎤 Voz") {
                runCatching {
                    voice.launch(
                        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                    )
                }.onFailure { Toast.makeText(ctx, "Busca por voz indisponível neste aparelho", Toast.LENGTH_SHORT).show() }
            }
        }
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(130.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) { items(results) { PosterCard(it.toPoster(), onOpen) } }
    }
}

// ═════════════════════════════ MINHA LISTA ═════════════════════════════
@Composable
fun MyListScreen(onOpen: (Poster) -> Unit) {
    val mine by LauncherApp.db.dao().all().collectAsState(emptyList())
    if (mine.none { it.inList || it.watched || it.watching }) {
        Box(Modifier.fillMaxSize(), Alignment.Center) {
            T("Nada por aqui ainda. Abra um título e use “+ Minha lista”.", 16)
        }
        return
    }
    LazyColumn(contentPadding = PaddingValues(bottom = 48.dp)) {
        item { PosterRow("Continuar assistindo", mine.filter { it.watching }.map { it.toPoster() }, onOpen) }
        item { PosterRow("Minha lista", mine.filter { it.inList }.map { it.toPoster() }, onOpen) }
        item { PosterRow("Já assisti", mine.filter { it.watched }.map { it.toPoster() }, onOpen) }
    }
}

// ═════════════════════════════ APPS ═════════════════════════════
class AppEntry(val label: String, val icon: ImageBitmap, val intent: Intent)

fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    fun query(cat: String) = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)
    return (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
        .distinctBy { it.activityInfo.packageName }
        .filter { it.activityInfo.packageName != ctx.packageName }
        .mapNotNull { ri ->
            val pkg = ri.activityInfo.packageName
            val intent = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
            intent?.let { AppEntry(ri.loadLabel(pm).toString(), ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap(), it) }
        }
        .sortedBy { it.label.lowercase() }
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    val apps = remember { loadApps(ctx) }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(110.dp),
        contentPadding = PaddingValues(horizontal = 48.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        items(apps) { a ->
            Focusable({ runCatching { ctx.startActivity(a.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) {
                Column(
                    Modifier.width(110.dp).background(Color(0x22FFFFFF)).padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Image(a.icon, null, Modifier.size(56.dp))
                    T(a.label, 12, maxLines = 1)
                }
            }
        }
    }
}
