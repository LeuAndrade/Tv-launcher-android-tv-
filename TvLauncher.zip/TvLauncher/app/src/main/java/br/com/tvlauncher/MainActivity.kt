package br.com.tvlauncher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface Screen {
    data object Home : Screen
    data object Search : Screen
    data object MyList : Screen
    data object Apps : Screen
    data class Detail(val type: String, val id: Int) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppTheme { Root() } }
    }
}

@Composable
fun Root() {
    var stack by remember { mutableStateOf<List<Screen>>(listOf(Screen.Home)) }
    val current = stack.last()

    // Como launcher, "Voltar" na tela inicial não faz nada.
    BackHandler {
        stack = when {
            stack.size > 1 -> stack.dropLast(1)
            current !is Screen.Home -> listOf(Screen.Home)
            else -> stack
        }
    }
    val openTitle: (Poster) -> Unit = { stack = stack + Screen.Detail(it.type, it.id) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        if (current !is Screen.Detail) TopBar(current) { stack = listOf(it) }
        when (current) {
            Screen.Home -> HomeScreen(openTitle)
            Screen.Search -> SearchScreen(openTitle)
            Screen.MyList -> MyListScreen(openTitle)
            Screen.Apps -> AppsScreen()
            is Screen.Detail -> DetailScreen(current.type, current.id, openTitle)
        }
    }
}

@Composable
fun TopBar(current: Screen, onTab: (Screen) -> Unit) {
    val time by produceState("") {
        while (true) {
            value = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            delay(15_000)
        }
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 48.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Btn("Início", current is Screen.Home) { onTab(Screen.Home) }
        Btn("Buscar", current is Screen.Search) { onTab(Screen.Search) }
        Btn("Minha lista", current is Screen.MyList) { onTab(Screen.MyList) }
        Btn("Apps", current is Screen.Apps) { onTab(Screen.Apps) }
        Spacer(Modifier.weight(1f))
        T(time, 18, true)
    }
}
