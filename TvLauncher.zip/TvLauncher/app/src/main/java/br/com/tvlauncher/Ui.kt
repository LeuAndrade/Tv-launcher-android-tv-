package br.com.tvlauncher

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.*
import coil.compose.AsyncImage

val Bg = Color(0xFF0E0F13)
val Accent = Color(0xFFE50914)

fun img(path: String?, size: String = "w342"): String? = path?.let { "https://image.tmdb.org/t/p/$size$it" }

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        CompositionLocalProvider(LocalContentColor provides Color.White) { content() }
    }
}

@Composable
fun T(
    text: String, size: Int = 14, bold: Boolean = false, modifier: Modifier = Modifier,
    color: Color = Color.Unspecified, maxLines: Int = Int.MAX_VALUE
) = Text(
    text, modifier, color = color, fontSize = size.sp,
    fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
    maxLines = maxLines, overflow = TextOverflow.Ellipsis
)

@Composable
fun Btn(text: String, selected: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.colors(
            containerColor = if (selected) Accent.copy(alpha = 0.6f) else Color(0x33FFFFFF),
            contentColor = Color.White,
            focusedContainerColor = Color.White,
            focusedContentColor = Color.Black
        )
    ) { Text(text, fontSize = 14.sp) }
}

/** Item focável pelo controle remoto: aumenta e ganha borda quando focado. */
@Composable
fun Focusable(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (focused) 1.08f else 1f, label = "focusScale")
    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier
            .onFocusChanged { focused = it.isFocused }
            .scale(s)
            .clip(shape)
            .then(if (focused) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .clickable(onClick = onClick),
        content = content
    )
}

@Composable
fun PosterCard(p: Poster, onOpen: (Poster) -> Unit, width: Dp = 130.dp) {
    Focusable({ onOpen(p) }, Modifier.width(width).height(width * 1.5f)) {
        AsyncImage(
            img(p.poster), p.title,
            Modifier.fillMaxSize().background(Color(0xFF22252E)),
            contentScale = ContentScale.Crop
        )
        if (p.poster == null) T(p.title, 12, modifier = Modifier.padding(8.dp))
        if (p.progress > 0) {
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(5.dp).background(Color(0x99000000))) {
                Box(Modifier.fillMaxWidth(p.progress / 100f).fillMaxHeight().background(Accent))
            }
        }
    }
}

@Composable
fun PosterRow(title: String, items: List<Poster>, onOpen: (Poster) -> Unit) {
    if (items.isEmpty()) return
    Column {
        T(title, 18, true, Modifier.padding(start = 48.dp, top = 16.dp, bottom = 8.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) { items(items) { PosterCard(it, onOpen) } }
    }
}

@Composable
fun Chip(text: String) {
    Box(
        Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0x33FFFFFF))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) { T(text, 13, true) }
}
