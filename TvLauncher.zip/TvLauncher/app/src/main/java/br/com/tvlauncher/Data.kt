package br.com.tvlauncher

import android.app.Application
import androidx.room.*
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

// ───────────── Modelos TMDB (tudo anulável: o Gson ignora os valores padrão do Kotlin) ─────────────
data class Page(val results: List<MediaItem>?)

data class MediaItem(
    val id: Int,
    @SerializedName("media_type") val mediaType: String?,
    val title: String?,
    val name: String?,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    val overview: String?,
    @SerializedName("vote_average") val voteAverage: Double?,
    @SerializedName("release_date") val releaseDate: String?,
    @SerializedName("first_air_date") val firstAirDate: String?
) {
    val label get() = title ?: name ?: ""
    val year get() = (releaseDate ?: firstAirDate)?.take(4) ?: ""
}

data class Genre(val name: String?)
data class Cast(val name: String?)
data class Credits(val cast: List<Cast>?)
data class Video(val key: String?, val site: String?, val type: String?)
data class Videos(val results: List<Video>?)
data class ExternalIds(@SerializedName("imdb_id") val imdbId: String?)
data class Provider(
    @SerializedName("provider_name") val name: String?,
    @SerializedName("logo_path") val logo: String?
)
data class Region(
    val link: String?,
    val flatrate: List<Provider>?,
    val rent: List<Provider>?,
    val buy: List<Provider>?
)
data class Providers(val results: Map<String, Region>?)

data class Detail(
    val id: Int,
    val title: String?,
    val name: String?,
    val tagline: String?,
    val overview: String?,
    @SerializedName("poster_path") val posterPath: String?,
    @SerializedName("backdrop_path") val backdropPath: String?,
    @SerializedName("vote_average") val voteAverage: Double?,
    @SerializedName("release_date") val releaseDate: String?,
    @SerializedName("first_air_date") val firstAirDate: String?,
    val runtime: Int?,
    val genres: List<Genre>?,
    @SerializedName("imdb_id") val imdbId: String?,
    @SerializedName("external_ids") val externalIds: ExternalIds?,
    val credits: Credits?,
    val videos: Videos?,
    @SerializedName("watch/providers") val providers: Providers?
) {
    val label get() = title ?: name ?: ""
    val year get() = (releaseDate ?: firstAirDate)?.take(4) ?: ""
    val imdb get() = imdbId ?: externalIds?.imdbId
    val trailerKey: String?
        get() {
            val yt = videos?.results.orEmpty().filter { it.site == "YouTube" }
            return (yt.firstOrNull { it.type == "Trailer" } ?: yt.firstOrNull())?.key
        }
}

// ───────────── Modelo OMDb (IMDb / Rotten Tomatoes / Metacritic) ─────────────
data class OmdbRating(@SerializedName("Source") val source: String?, @SerializedName("Value") val value: String?)
data class Omdb(@SerializedName("Ratings") val ratings: List<OmdbRating>?)

// ───────────── Retrofit ─────────────
interface Tmdb {
    @GET("trending/all/week") suspend fun trending(): Page
    @GET("movie/now_playing?region=BR") suspend fun nowPlaying(): Page
    @GET("movie/popular?region=BR") suspend fun popularMovies(): Page
    @GET("tv/popular") suspend fun popularTv(): Page
    @GET("movie/top_rated?region=BR") suspend fun topMovies(): Page
    @GET("search/multi") suspend fun search(@Query("query") q: String): Page
    @GET("{type}/{id}/recommendations") suspend fun recommendations(
        @Path("type") type: String, @Path("id") id: Int
    ): Page

    @GET("{type}/{id}?append_to_response=credits,videos,watch/providers,external_ids&include_video_language=pt,en,null")
    suspend fun detail(@Path("type") type: String, @Path("id") id: Int): Detail
}

interface OmdbApi {
    @GET("/") suspend fun byImdb(@Query("i") imdbId: String, @Query("apikey") key: String): Omdb
}

object Net {
    private val tmdbClient = OkHttpClient.Builder().addInterceptor { chain ->
        val url = chain.request().url.newBuilder()
            .addQueryParameter("api_key", BuildConfig.TMDB_KEY)
            .addQueryParameter("language", "pt-BR")
            .build()
        chain.proceed(chain.request().newBuilder().url(url).build())
    }.build()

    val tmdb: Tmdb = Retrofit.Builder()
        .baseUrl("https://api.themoviedb.org/3/")
        .client(tmdbClient)
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(Tmdb::class.java)

    val omdb: OmdbApi = Retrofit.Builder()
        .baseUrl("https://www.omdbapi.com/")
        .addConverterFactory(GsonConverterFactory.create())
        .build().create(OmdbApi::class.java)
}

// ───────────── Room: lista, assistido, continuar assistindo ─────────────
@Entity(tableName = "titles")
data class UserTitle(
    @PrimaryKey val uid: String,          // "movie:123" ou "tv:456"
    val id: Int,
    val type: String,
    val title: String,
    val poster: String?,
    val backdrop: String?,
    val inList: Boolean = false,
    val watched: Boolean = false,
    val watching: Boolean = false,
    val progress: Int = 0,                // 0..100
    val updatedAt: Long = 0
)

@Dao
interface TitleDao {
    @Query("SELECT * FROM titles ORDER BY updatedAt DESC") fun all(): Flow<List<UserTitle>>
    @Query("SELECT * FROM titles WHERE uid = :uid") fun one(uid: String): Flow<UserTitle?>
    @Upsert suspend fun upsert(t: UserTitle)
}

@Database(entities = [UserTitle::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() { abstract fun dao(): TitleDao }

class LauncherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, AppDb::class.java, "launcher.db").build()
    }
    companion object { lateinit var db: AppDb }
}

// ───────────── Modelo de exibição + repositório ─────────────
data class Poster(
    val id: Int, val type: String, val title: String,
    val poster: String?, val backdrop: String?, val progress: Int = 0
)

fun MediaItem.toPoster() = Poster(id, mediaType ?: "movie", label, posterPath, backdropPath)
fun UserTitle.toPoster() = Poster(id, type, title, poster, backdrop, if (watching) progress else 0)

data class Shelf(val title: String, val items: List<MediaItem>)

object Repo {
    private val api get() = Net.tmdb

    private fun Page.typed(t: String?) = results.orEmpty()
        .map { it.copy(mediaType = it.mediaType ?: t) }
        .filter { it.mediaType == "movie" || it.mediaType == "tv" }

    private suspend fun safe(block: suspend () -> List<MediaItem>) =
        runCatching { block() }.getOrDefault(emptyList())

    suspend fun homeShelves(): List<Shelf> = coroutineScope {
        val trending = async { safe { api.trending().typed(null) } }
        val cinema = async { safe { api.nowPlaying().typed("movie") } }
        val movies = async { safe { api.popularMovies().typed("movie") } }
        val series = async { safe { api.popularTv().typed("tv") } }
        val top = async { safe { api.topMovies().typed("movie") } }
        listOf(
            Shelf("Em alta esta semana", trending.await()),
            Shelf("Em cartaz", cinema.await()),
            Shelf("Filmes populares", movies.await()),
            Shelf("Séries populares", series.await()),
            Shelf("Mais bem avaliados", top.await())
        )
    }

    suspend fun recommendations(seed: UserTitle?): List<MediaItem> =
        if (seed == null) safe { api.topMovies().typed("movie") }
        else similar(seed.type, seed.id)

    suspend fun similar(type: String, id: Int): List<MediaItem> =
        safe { api.recommendations(type, id).typed(type) }

    suspend fun search(q: String): List<MediaItem> = safe { api.search(q).typed(null) }

    suspend fun ratings(imdbId: String): Omdb? =
        runCatching { Net.omdb.byImdb(imdbId, BuildConfig.OMDB_KEY) }.getOrNull()
}
